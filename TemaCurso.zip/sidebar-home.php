<?php

if(is_active_sidebar('sidebar-1')){
	dynamic_sidebar('sidebar-1');
}
//Faz chamada ao formulario de contato Contatc Form 7
echo do_shortcode('[contact-form-7 id="132" title="Formúlario Sidebar"]');