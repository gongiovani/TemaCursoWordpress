<?php 

function meupersonalizador($wp_customize){

	// Seção Copyright
	$wp_customize->add_section( 'sec_copyright', array(
		'title' 		=> 'Copyright',
		'description' 	=> 'Seção para o Copyright'
	));

	$wp_customize->add_setting('set_copyright', array(
		'type' 		=> 'theme_mod',
		'default'	=> 'Copyright - Todos os Direitos Reservados'
	));

	$wp_customize->add_control('ctrl_copyright', array(
		'label' 		=> 'Copyright',
		'description' 	=> 'Informe o Copyright',
		'section'		=> 'sec_copyright',
		'settings'		=> 'set_copyright',
		'type'			=> 'text'
	));


	// Seção Serviços -----------------------------------------------------

	$wp_customize->add_section( 'sec_servicos', array(
		'title' 		=> 'Serviços',
		'description' 	=> 'Seção para o Serviços'
	));

	// Serviço 1 -----------------------------------------------------
	$wp_customize->add_setting('set_servicos1', array(
		'type' 		=> ''
	));

	$wp_customize->add_control(new WP_customize_Cropped_Image_Control($wp_customize, 'ctrl_servicos_item1', array(
		'label'		=> 'Imagem do Serviço 1',
		'width'		=> 200,
		'heigth'	=> 200,
		'section'	=> 'sec_servicos',
		'settings'	=> 'set_servicos1'
	)));

	// Serviço 2 -----------------------------------------------------
	$wp_customize->add_setting('set_servicos2', array(
		'type' 		=> ''
	));

	$wp_customize->add_control(new WP_customize_Cropped_Image_Control($wp_customize, 'ctrl_servicos_item2', array(
		'label'		=> 'Imagem do Serviço 2',
		'width'		=> 200,
		'heigth'	=> 200,
		'section'	=> 'sec_servicos',
		'settings'	=> 'set_servicos2'
	)));

	// Serviço 3 -----------------------------------------------------
	$wp_customize->add_setting('set_servicos3', array(
		'type' 		=> ''
	));

	$wp_customize->add_control(new WP_customize_Cropped_Image_Control($wp_customize, 'ctrl_servicos_item3', array(
		'label'		=> 'Imagem do Serviço 3',
		'width'		=> 200,
		'heigth'	=> 200,
		'section'	=> 'sec_servicos',
		'settings'	=> 'set_servicos3'
	)));

}
add_action('customize_register', 'meupersonalizador');
