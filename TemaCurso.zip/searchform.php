<!-- Formulario de pesquisa do CAMPO PESQUISA -->
<form role="search" method="get" action="<?php echo home_url('/'); ?>">
	<input type="search"
			class="form-control"
			placeholder="Pesquisa"
			value="<?php echo get_search_query(); ?>"
			name="s" title="Pesquisa" />
</form>