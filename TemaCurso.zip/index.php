<?php get_header(); //Faz chamada do arquivo header.php?>

<img class="img-responsive" src="<?php header_image(); ?>" height="
	<?php echo get_custom_header()->height; ?>" 
	width="<?php echo get_custom_header()->width; ?>" alt=" " />

	<div class="conteudo">
		<main>
			<section class="meio">
				<div class="container">
					<div class="row">
					
						<div class="blog col-md-9 ">
							
							<?php 
								// Se houver post
								if(have_posts() ):
									// Enquanto houver post, chame o post
									while (have_posts()) : the_post();
							?>
							
							<?php get_template_part('content', get_post_format()); //Faz um iclude do arquivo content, e o get_post busca o tipo de arquivo, se é video ou imagem ?>

							<?php 
								endwhile;

							?>


							<div class="paginacao text-left">
								<?php next_posts_link("<< Mais Antigos") // Paginação dos posts ?>
								
							</div>

							<div class="paginacao text-right">
								<?php previous_posts_link("Mais novos >>") // Paginação dos posts ?>
							</div>

							<?php
								else:
							?>
								<p>Não tem nada para mostrar</p>
							<?php 
							endif
							?>
							
						</div>

						<aside class="barra-lateral col-md-3 ">
							<?php get_sidebar('blog'); // Faz a chamada do arquivo SIDEBAR-BLOG.php?> 
						</aside>

					</div>
				</div>
			</section>
		</main>
	</div>
<?php get_footer(); //Faz chamada do arquivo footer.php?> 
