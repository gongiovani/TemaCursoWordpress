<?php 
/*
Template name: Pagina Gerais
*/

//PARA AS PAGINAS: QUEM SOMOS E CONTATO
?>

<?php get_header(); //Faz chamada do arquivo header.php?>

<img class="img-responsive" src="<?php header_image(); ?>" height="
	<?php echo get_custom_header()->height; ?>" 
	width="<?php echo get_custom_header()->width; ?>" alt=" " />

	<div class="conteudo-wrapper">
		<main>

			<div class="conteudo container">

				<?php 
							// Se houver post
							if(have_posts() ):
								// Enquanto houver post, chame o post
								while (have_posts()) : the_post();
						?>
							<h1><?php the_title(); ?></h1>
							<p><?php the_content(); ?></p>
						<?php 
							endwhile;
								else:
						?>
							<p>Não tem nada para mostrar</p>
						<?php 
						endif
						?>
						
				
			</div>
		</main>
	</div>
<?php get_footer(); //Faz chamada do arquivo footer.php?> 
