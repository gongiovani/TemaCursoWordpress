<footer>
	<div class="container">
		<div class="row">
			<div class="copyright col-md-5 col-sm-5 col-xs-4">
				<?php echo get_theme_mod('set_copyright') ?>
			</div>

			<div class="menu-rodape col-md-7 col-sm-7 col-xs-8 text-right">
				<?php wp_nav_menu( array('theme_location' => 'meu_menu_secundario') ); ?>
			</div>
		</div>
	</div>	

</footer>

<?php wp_footer(); ?>

</body>
</html>